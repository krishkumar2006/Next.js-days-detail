import Footer from "@/components/Footer/Footer"
import ShopPage from "../../components/shop-header/shop-header"
import Itemlist from "@/components/itemList/itemList"

const Shop = () => {
  return (
    <>
 <ShopPage />
<Itemlist/>
<Footer/>
  
    </>
  )
}

export default Shop