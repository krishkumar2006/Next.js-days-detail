import Aboutpage from "@/components/about-header/about-header"


const About = () => {
  return (
    <>
    <Aboutpage />
    </>
  )
}

export default About