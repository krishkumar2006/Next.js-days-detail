import ContactPage from '@/components/content-p/content-p'
import React from 'react'

const Contact = () => {
  return (
    <>
    <ContactPage />
    </>
  )
}

export default Contact