import React from 'react'
import Cart from "../../components/cart/cart"

export default function Cartp() {
  return (
    <div>
      <Cart></Cart>
    </div>
  )
}
