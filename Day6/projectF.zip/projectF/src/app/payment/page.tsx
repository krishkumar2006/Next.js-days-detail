import StripePayment from '@/components/stripepayment'
import React from 'react'

const page = () => {
  return (
    <div>
      <StripePayment/>
    </div>
  )
}

export default page
