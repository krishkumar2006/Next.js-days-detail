import React from 'react'
import Link from 'next/link'
import Accountpage from "../../components/account/account"

const Account = () => {
  return (
    <div>
      <Accountpage></Accountpage>
    </div>
  )
}

export default Account
