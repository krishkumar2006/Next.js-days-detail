import Checkout from "@/components/Checkout/Checkout";

import React from 'react'

const page = () => {
  return (
    <div>
      <Checkout></Checkout>
    </div>
  )
}

export default page
