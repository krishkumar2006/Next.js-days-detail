(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_35eb13._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_35eb13._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_64b94d._.js",
    "static/chunks/src_app_page_tsx_8b213b._.js"
  ],
  "source": "dynamic"
});
