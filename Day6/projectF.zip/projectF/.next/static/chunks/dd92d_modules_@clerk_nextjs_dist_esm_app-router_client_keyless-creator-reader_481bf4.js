(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/dd92d_modules_@clerk_nextjs_dist_esm_app-router_client_keyless-creator-reader_481bf4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/dd92d_modules_@clerk_nextjs_dist_esm_app-router_client_keyless-creator-reader_481bf4.js",
  "chunks": [
    "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_8c9dc8._.js"
  ],
  "source": "dynamic"
});
