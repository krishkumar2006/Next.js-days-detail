(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_studio_[[___tool]]_page_tsx_b99c9c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_studio_[[___tool]]_page_tsx_b99c9c._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_136da5._.js",
    "static/chunks/node_modules_sanity_lib__chunks-es_39c17d._.js",
    "static/chunks/node_modules_sanity_lib_index_mjs_3361d2._.js",
    "static/chunks/node_modules_sanity_lib_b85b34._.js",
    "static/chunks/node_modules_rxjs_dist_esm5_internal_cf1c6e._.js",
    "static/chunks/node_modules_@sanity_ui_dist_b28664._.js",
    "static/chunks/node_modules_@sanity_icons_dist_index_068d3b.js",
    "static/chunks/node_modules_framer-motion_dist_es_8e713b._.js",
    "static/chunks/node_modules_next_dist_a89c61._.js",
    "static/chunks/node_modules_date-fns_84e473._.js",
    "static/chunks/node_modules_@sanity_schema_lib_023474._.js",
    "static/chunks/node_modules_slate_dist_index_es_52fdc9.js",
    "static/chunks/node_modules_slate-react_dist_index_es_a2aa2c.js",
    "static/chunks/node_modules_xstate_895663._.js",
    "static/chunks/node_modules_@portabletext_editor_lib_83b01e._.js",
    "static/chunks/node_modules_@dnd-kit_core_dist_core_esm_deb93f.js",
    "static/chunks/node_modules_moment_5ca364._.js",
    "static/chunks/node_modules_groq-js_dist_1_mjs_e72415._.js",
    "static/chunks/node_modules_@sentry_core_build_esm_5f9912._.js",
    "static/chunks/node_modules_@sentry_browser_build_npm_esm_4597a4._.js",
    "static/chunks/node_modules_polished_dist_polished_esm_5b2c37.js",
    "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_dc7bc5._.js",
    "static/chunks/node_modules_@sanity_7c92a3._.js",
    "static/chunks/node_modules_@floating-ui_9ec1fa._.js",
    "static/chunks/node_modules_96295b._.js",
    "static/chunks/_c66763._.js",
    "static/chunks/node_modules_b87894._.js"
  ],
  "source": "dynamic"
});
