(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_checkout_page_tsx_0cf6ee._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_checkout_page_tsx_0cf6ee._.js",
  "chunks": [
    "static/chunks/_a4c9f2._.js"
  ],
  "source": "dynamic"
});
