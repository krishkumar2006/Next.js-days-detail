(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_furniture_[id]_page_tsx_0cf6ee._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_furniture_[id]_page_tsx_0cf6ee._.js",
  "chunks": [
    "static/chunks/node_modules_811326._.js",
    "static/chunks/src_75af32._.js",
    "static/chunks/node_modules_@sanity_c79b52._.js"
  ],
  "source": "dynamic"
});
