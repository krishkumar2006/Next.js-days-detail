(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_0cf6ee._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_0cf6ee._.js",
  "chunks": [
    "static/chunks/node_modules_45d926._.js",
    "static/chunks/_7204f0._.js",
    "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_370d7c._.js"
  ],
  "source": "dynamic"
});
